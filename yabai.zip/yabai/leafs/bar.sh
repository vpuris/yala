#!/bin/bash

# Kill all running Waybar instances
killall waybar

# Wait a moment to make sure it's fully closed
sleep 1

# Start Waybar again
waybar &
